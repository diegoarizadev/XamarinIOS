﻿using System;
namespace _19.TableViewExpandible
{
    public class Datos
    {

        public String Name { get; set; }
        public String Description { get; set; }

        public Datos(string name, string descripcion)
        {
            Name = name;
            Description = descripcion;
        }
    }
}
