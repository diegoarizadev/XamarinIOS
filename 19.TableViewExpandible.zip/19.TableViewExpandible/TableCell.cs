﻿using System;
using Foundation;
using UIKit;

namespace _19.TableViewExpandible
{
    public partial class TableCell : UITableViewCell
    {

        public static readonly NSString Key = new NSString("TableViewCell");
        public static readonly UINib Nib;

        public TableCell(IntPtr handle) : base(handle)
        {
        }

        static TableCell()
        {
            Nib = UINib.FromName("TableViewCell", NSBundle.MainBundle);
        }

    

    }
}

