﻿using Foundation;
using System;
using System.Collections.Generic;
using UIKit;

namespace _19.TableViewExpandible
{
    public partial class ViewController : UIViewController
    {

        private MyTableSource SourceClass;
        public List<Datos> data { get; set; }


        public ViewController(IntPtr handle) : base(handle)
        {
        }

        public override void ViewDidLoad()
        {
            base.ViewDidLoad();

            data = llenarLista();

            InvokeOnMainThread(() =>
            {
                SourceClass = new MyTableSource(data);
                MyTable.Source = SourceClass;
                MyTable.ReloadData();
            });

        }

        public override void DidReceiveMemoryWarning()
        {
            base.DidReceiveMemoryWarning();
     
        }

        public List<Datos> llenarLista()
        {
            var InfoList = new List<Datos>()
            {

                new Datos("Lorem Ipsum", "is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book"),
                new Datos("Lorem Ipsum", "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse iaculis nulla quis risus hendrerit vulputate id quis purus. Aenean orci ante, sodales non laoreet sit amet, varius at justo. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas."),
                new Datos("Lorem Ipsum", "Proin malesuada, urna nec venenatis facilisis, velit mauris molestie lectus, quis faucibus leo urna non nulla. Nullam maximus eros felis, vitae dapibus lacus feugiat ac. Aenean vel quam ac sem laoreet tincidunt quis sed felis. Morbi tincidunt arcu vitae augue ornare commodo. Ut commodo ante quis faucibus imperdiet"),
                new Datos("Lorem Ipsum", "is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book"),
                new Datos("Lorem Ipsum", "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse iaculis nulla quis risus hendrerit vulputate id quis purus. Aenean orci ante, sodales non laoreet sit amet, varius at justo. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas."),
                new Datos("Lorem Ipsum", "Proin malesuada, urna nec venenatis facilisis, velit mauris molestie lectus, quis faucibus leo urna non nulla. Nullam maximus eros felis, vitae dapibus lacus feugiat ac. Aenean vel quam ac sem laoreet tincidunt quis sed felis. Morbi tincidunt arcu vitae augue ornare commodo. Ut commodo ante quis faucibus imperdiet"),
                new Datos("Lorem Ipsum", "is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book"),
                new Datos("Lorem Ipsum", "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse iaculis nulla quis risus hendrerit vulputate id quis purus. Aenean orci ante, sodales non laoreet sit amet, varius at justo. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas."),
                new Datos("Lorem Ipsum", "Proin malesuada, urna nec venenatis facilisis, velit mauris molestie lectus, quis faucibus leo urna non nulla. Nullam maximus eros felis, vitae dapibus lacus feugiat ac. Aenean vel quam ac sem laoreet tincidunt quis sed felis. Morbi tincidunt arcu vitae augue ornare commodo. Ut commodo ante quis faucibus imperdiet"),

            };
            return InfoList;
        }
    }
}